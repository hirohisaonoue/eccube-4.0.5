#!/bin/sh

cd $(dirname $0)

tar cvzf ../SheebExpandProductColumn.tar.gz *